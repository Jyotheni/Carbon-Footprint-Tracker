# MentalHealthAnalysis
Analyze users mental health state based on the contents they have consumed/posted in social media.
